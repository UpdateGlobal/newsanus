<!DOCTYPE html>
<html lang="es">
<html>
<?
include 'includes/head.php'
?>
<body>

<?
include 'includes/preloader.php'
?>

<?
include 'includes/header-nav-interiores.php'
?>
    
<div class="main-wrapper">
<?
include 'includes/subheader.php'
?>
        <!-- INICIO NOTA BLOG -->

<?
include 'includes/contenido-nota.php'
?>

        <!-- END NOTA BLOG -->


        <!-- FOOTER -->
        <?
        include 'includes/footer.php'
        ?> 
        <!-- FOOTER -->


</div> <!-- main-wrapper -->

<!-- SCRIPTS -->
        <?
        include 'includes/scripts.php'
        ?> 
<!-- SCRIPTS -->
</body>
</html>
