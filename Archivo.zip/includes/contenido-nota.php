<div class="container_gray_bg">
<div class="container margin_60">
 		<div class="row">
  
           <div class="col-md-9">
                	<div class="box_style_1">

                   	<div class="indent_title_in">
                    <i class="pe-7s-news-paper"></i>
				        <h3>Lorem Ipsum dolot</h3>
				        <p>por Dr. Luis Velasco</p> <br>
			         <div class="post"></div><img src="img/blog-3.jpg" alt="" class="img-responsive"></div> <br>
            	<div class="wrapper_indent">
                    <p style="text-align: justify;">Lorem ipsum dolor sit amet, nam ei aperiam dolorum nominati, porro possit ne qui, <strong>libris consectetuer</strong> has no. Te saepe epicurei apeirian his, vim an minim delicatissimi. Et ius tota recusabo democritum, cum choro consul urbanitas eu. At nemore quodsi concludaturque per, nam adhuc noster accusam ad. Vim id aliquid dolorum, nam case graece ea.</p>
                    <p>Zril causae ancillae sit ea. Dicam veritus mediocritatem sea ex, nec id agam eius. Te pri facete latine salutandi, scripta mediocrem et sed, cum ne mundi vulputate. Ne his sint graeco detraxit, posse exerci volutpat has in.</p>
                    <p class="add_bottom_30">Lorem ipsum dolor sit amet, nam ei aperiam <strong>dolorum nominati</strong>, porro possit ne qui, libris consectetuer has no. Te saepe epicurei apeirian his, vim an minim delicatissimi. Et ius tota recusabo democritum, cum choro consul urbanitas eu. At nemore quodsi concludaturque per, nam <a href="#" class="hvr-underline-reveal"><strong>adhuc noster accusam ad</strong></a>. Vim id aliquid dolorum, nam case graece ea.</p>
                    <div class="row">
                        <div class="col-md-6">
                            <ul class="list_style_1">
                                <li>History</li>
                                <li>Natural Science</li>
                                <li>Social Science</li>
                                <li>Mathematics</li>
                            </ul>
                        </div>
                        <div class="col-md-6">
                            <ul class="list_style_1">
                                <li>Writing</li>
                                <li>Literature</li>
                                <li>Social Science</li>
                                <li>Cultural Diversity</li>
                            </ul>
                        </div>
                    </div>
                    </div>
                  
                    
                    </div>
           </div>
           <?
           include 'banner-aside.php'
           ?>
        </div><!--End row -->

        </div><!--End container -->
    </div>