<header>
		<a id="logo" href="index.php"><img src="img/logo-sanus1.png" width="125" height="40" alt="Atena" data-retina="true"></a>
		<nav id="top-nav">
			<ul>
            	
				<li><a href="#somos">SANUS</a></li>
                <li><a href="#como">CÓMO USAR</a></li>
                <li><a href="#">REGÍSTRATE GRATIS</a></li>
                <li><a href="#">INGRESA</a></li>
                <li><a href="blog.php">BLOG</a></li>
			</ul>
		</nav>
		<a id="menu-trigger" href="#"><span class="menu-trigger-text"></span><span class="menu-trigger-icon"></span></a>
	</header>
<!-- End Header -->

<!-- Nav -->    
    <nav id="side-nav">
		<ul class="side-nav-menu">
		<li class="item-has-children">
				<a href="#porque">Beneficios</a>
		</li>    
         <li class="item-has-children">
				<a href="#">Registrate</a>
		</li> <!-- item-has-children -->        
        <li class="item-has-children">
				<a href="#">Ingresa</a>
		</li> 
		<li class="item-has-children">
				<a href="#">Contacto</a>
		</li>
		<li class="item-has-children">
				<a href="blog.php">Blog</a>
		</li> 
			<!-- item-has-children -->
         </ul> 
    <!-- side-nav-menu -->
		<div id="social">
            <ul>
               <li><a href="#"><i class="icon-facebook"></i></a></li>
               <li><a href="#"><i class="icon-twitter"></i></a></li>
               <li><a href="#"><i class="icon-youtube"></i></a></li>
               <li><a href="#"><i class="icon-linkedin"></i></a></li>
           </ul>
       </div>
	</nav>
<!--End nav-->