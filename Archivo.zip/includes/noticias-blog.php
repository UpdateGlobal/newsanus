<div style="background-color: #e8f2f3;"> 
    <div class="container margin_60">
        <section id="section-2">
    						<div class="row list_news_tabs">
                            	<div class="col-md-4 col-sm-4">
                                <p><a href="blog-post.php"><img src="img/news_1_thumb.jpg" alt="" class="img-responsive"></a></p>
                                      <span class="date_published">20 Agusut 2017</span>
    							<h3><a href="#0">Lorem ipsum dolor sit amet</a></h3>
                                <p>Lorem ipsum dolor sit amet, ei tincidunt persequeris efficiantur vel, usu animal patrioque omittantur et. Timeam nostrud platonem nec ea, simul nihil delectus has ex. </p>
                                <a href="#0" class="button small">Leer más...</a>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                <p><a href="blog-post.php"><img src="img/news_2_thumb.jpg" alt="" class="img-responsive"></a></p>
                                      <span class="date_published">20 Agusut 2017</span>
    							<h3><a href="blog-post.php">Lorem ipsum dolor sit amet</a></h3>
                                <p>Lorem ipsum dolor sit amet, ei tincidunt persequeris efficiantur vel, usu animal patrioque omittantur et. Timeam nostrud platonem nec ea, simul nihil delectus has ex. </p>
                                <a href="blog-post.php" class="button small">Leer más...</a>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                <p><a href="blog-post.php"><img src="img/news_3_thumb.jpg" alt="" class="img-responsive"></a></p>
                                      <span class="date_published">20 Agusut 2017</span>
    							<h3><a href="blog-post.php">Lorem ipsum dolor sit amet</a></h3>
                                <p>Lorem ipsum dolor sit amet, ei tincidunt persequeris efficiantur vel, usu animal patrioque omittantur et. Timeam nostrud platonem nec ea, simul nihil delectus has ex. </p>
                                <a href="blog-post.php" class="button small">Leer más...</a>
                                </div>
                            </div>

    	</section>

	</div>
</div>