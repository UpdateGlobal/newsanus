<footer>
        <div class="container">
            <div class="row ">
                <div class="col-md-3 col-sm-3">
                    <p id="logo_footer">
                        <img src="img/logo-sanus2.png" width="125" height="40" alt="Atena" data-retina="true">
                    </p>
                </div>
                <div class="col-md-3 col-sm-3">
                    <h4>Nosotros</h4>
                    <ul>
                        <li><a href="#">¿Qué es Sanus?</a></li>
                        <li><a href="#">Cómo usar</a></li>
                        <li><a href="#">Regístrate</a></li>

                    </ul>
                </div>
                <div class="col-md-3 col-sm-3">
                    <h4>Clínica Virtual</h4>
                    <ul>
                        <li><a href="#">Ingresa</a></li>
                        <li><a href="#">Blog</a></li>
                        <li><a href="#">Terminos y Condiciones</a></li>
                    </ul>
                </div>
                <div class="col-md-3 col-sm-3">
                    <h4>Contactanos</h4>
                    <ul>
                        <li><a href="#">Contacto</a></li>
                    </ul>
                    <ul id="contacts_footer">
                        <li>Central: <a href="tel://033284322">+511 7176517</a></li>
                        <li>Email - <a href="#">[info@sanus.pe]</a></li>
                    </ul>
                </div>
            </div>
        </div>
</footer>
<!-- End footer -->

<!-- End copyright -->
<div id="copy">
    <div class="container">
        © SANUS 2018 - Todos los derechos reservados.
    </div>
</div>
<!-- End copyright -->