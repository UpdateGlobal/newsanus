<div class="bg_content magnific">
    <div>
         <h3>Descubre SANUS</h3>
         <a href="https://vimeo.com/20370747" class="video_pop"><i class="arrow_triangle-right_alt2"></i></a>
    </div>
</div>