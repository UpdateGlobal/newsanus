<aside class="col-md-3">
           
            <div class="banner">
                    <i class=" iconcustom-school"></i>
                    <h3>Reserva tu cita</h3>
                    <p>Zril causae ancillae sit ea. Dicam veritus mediocritatem sea ex, nec id agam eius.</p>
                    <a href="tour.html" class="banner_bt">Ingresar</a>
                    </div>
 
             
</aside>