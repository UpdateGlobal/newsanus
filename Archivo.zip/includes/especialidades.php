<div id="especialidades"  style="background-color: #e8f2f3;">
<div class="container margin_60">
    <div class="main_title">
    <h2 style="color:grey;">Nuestras <span style="color:#48bbc6; font-family: inherit;"><strong>especialidades</strong></span></h2>
    <p>SANUS cuenta con las siguientes especialidades a cargo de profesionales calificados.</p>
    </div><br>
        <div class="row">
                        <div class="col-md-3">
                            <ul class="list_style_1">
                                <li>History</li>
                                <li>Natural Science</li>
                                <li>Social Science</li>
                                <li>Mathematics</li>
                                <li>History</li>
                                <li>Natural Science</li>
                                <li>Social Science</li>
                                <li>Mathematics</li>
                            </ul>
                        </div>
                        <div class="col-md-3">
                            <ul class="list_style_1">
                                <li>Writing</li>
                                <li>Literature</li>
                                <li>Social Science</li>
                                <li>Cultural Diversity</li>
                                <li>Writing</li>
                                <li>Literature</li>
                                <li>Social Science</li>
                                <li>Cultural Diversity</li>
                            </ul>
                        </div>                        <div class="col-md-3">
                            <ul class="list_style_1">
                                <li>History</li>
                                <li>Natural Science</li>
                                <li>Social Science</li>
                                <li>Mathematics</li>
                                <li>History</li>
                                <li>Natural Science</li>
                                <li>Social Science</li>
                                <li>Mathematics</li>
                            </ul>
                        </div>                        <div class="col-md-3">
                            <ul class="list_style_1">
                                <li>Writing</li>
                                <li>Literature</li>
                                <li>Social Science</li>
                                <li>Cultural Diversity</li>
                                <li>Writing</li>
                                <li>Literature</li>
                                <li>Social Science</li>
                                <li>Cultural Diversity</li>
                            </ul>
                        </div>
        </div>
       
<br><br><br>

<!-- BUTTON -->
    <div class="text-center"><a href="tour.html" class=" button_outline large">Reserva tu cita</a></div>
<!-- BUTTON  -->   
</div>
</div>