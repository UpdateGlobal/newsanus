     <div id="somos" class="container margin_60">
        	<div class="main_title">
                
                 <div>
                       <img class="responsive" src="img/images/nosotros.png" width="300px" alt="" style="margin-top: 50px;">
                 </div>
                 <h2 style="color:grey;">¿Qué es <span style="color:#48bbc6; font-family: inherit;"><strong>SANUS?</strong></span></h2>


                 <p style="text-align: center; font-size: 20px; margin-top: 30px; margin-bottom: 100px;">
                         Somos un grupo médico multidisciplinario que apuesta por el uso las nuevas tecnologías como instrumento para facilitar el acceso a la salud. Confiamos en la telesalud como una plataforma amigable, cómoda y confiable que permite un fácil manejo a los usuarios y con especialistas de comprobada experiencia profesional, sin limitaciones de tiempo y espacio.
                    </p>
            </div>

            
     </div>