<div id="full-slider-wrapper">
<div id="layerslider" style="width:100%;height:650px;">
        <!-- first slide -->
        <div class="ls-slide" data-ls="slidedelay: 5000; transition2d:5;">
            <img src="img/slides/slide_3.jpg" class="ls-bg" alt="Slide background">
            <p class="ls-l slide_typo_2" style="top:38%; left:50%;" data-ls="durationin:2000;delayin:1000;easingin:easeOutElastic;" >BIENVENIDOS A SANUS</p>
        	<h3 class="ls-l slide_typo" style="top: 45%; left: 50%;" data-ls="offsetxin:0;durationin:2000;delayin:1000;easingin:easeOutElastic;rotatexin:90;transformoriginin:50% bottom 0;offsetxout:0;rotatexout:90;transformoriginout:50% bottom 0;"><strong>1ra Clínica Virtual del Perú</strong></h3>
            <p class="ls-l slide_typo_2" style="top:52%; left:50%;" data-ls="durationin:2000;delayin:1000;easingin:easeOutElastic;" >TELESALUD / CONSULTA MEDICA VIRTUAL</p>
            <p class="ls-l" style="top:62%; left:50%;" data-ls="durationin:2000;delayin:1300;easingin:easeOutElastic;" ><a href="#" class="button_intro">Registrate</a> <a href="about.html" class="button_intro outline">Ingresar</a></p>
       </div>
       
        <!-- second slide -->
        <div class="ls-slide" data-ls="slidedelay: 5000; transition2d:5;">
                <img  src="img/slides/slide_2.jpg" class="ls-bg" alt="Slide background">
                <p class="ls-l slide_typo_2" style="top:38%; left:50%;" data-ls="durationin:2000;delayin:1000;easingin:easeOutElastic;" >BIENVENIDOS A SANUS</p>
            	<h3 class="ls-l slide_typo" style="top: 45%; left: 50%;" data-ls="offsetxin:0;durationin:2000;delayin:1000;easingin:easeOutElastic;rotatexin:90;transformoriginin:50% bottom 0;offsetxout:0;rotatexout:90;transformoriginout:50% bottom 0;" ><strong>La 1ra Clínica Virtual del Perú</strong></h3>
                <p class="ls-l slide_typo_2" style="top:52%; left:50%;" data-ls="durationin:2000;delayin:1000;easingin:easeOutElastic;" >TELESALUD / CONSULTA MEDICA VIRTUAL</p>
                <p class="ls-l" style="top:65%; left:50%;" data-ls="durationin:2000;delayin:1300;easingin:easeOutElastic;" ><a href="#" class="button_intro">Registrate</a> <a href="about.html" class="button_intro outline">Ingresar</a></p>
        </div>
    
         <!-- third slide -->
         <div class="ls-slide" data-ls="slidedelay:5000; transition2d:5;" >
                 <img src="img/slides/slide_1.jpg" class="ls-bg" alt="Slide background">
                 <p class="ls-l slide_typo_2" style="top:38%; left:50%;" data-ls="durationin:2000;delayin:1000;easingin:easeOutElastic;" >BIENVENIDOS A SANUS</p>
            	<h3 class="ls-l slide_typo" style="top: 45%; left: 50%;" data-ls="offsetxin:0;durationin:2000;delayin:1000;easingin:easeOutElastic;rotatexin:90;transformoriginin:50% bottom 0;offsetxout:0;rotatexout:90;transformoriginout:50% bottom 0;" ><strong>La 1ra Clínica Virtual del Perú</strong></h3>
                <p class="ls-l slide_typo_2" style="top:52%; left:50%;" data-ls="durationin:2000;delayin:1000;easingin:easeOutElastic;" >TELESALUD / CONSULTA MEDICA VIRTUAL</p>
                <p class="ls-l" style="top:65%; left:50%;" data-ls="durationin:2000;delayin:1300;easingin:easeOutElastic;" ><a href="#" class="button_intro">Registrate</a> <a href="about.html" class="button_intro outline">Ingresar</a></p>
        </div>
    </div>
</div>