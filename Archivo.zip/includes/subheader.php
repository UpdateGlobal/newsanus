        <div class="sub_header bg_1">
        	<div id="intro_txt">
			<h1>Nuestro <strong>Blog</strong> SANUS</h1>
            <p>Ex saepe accusata duo, vel ne summo option delenit.</p>
            </div>
		</div>
        
        <div id="position">
            <div class="container">
                <ul>
                    <li><a href="#">Inicio</a></li>
                    <li><a href="#">Nuestro Blog</a></li>
                    <li>Nota Lorem Ipsum</li>
                </ul>
            </div>
        </div>