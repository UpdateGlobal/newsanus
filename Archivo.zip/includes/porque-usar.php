<div id="porque" class="container margin_60">
    <div class="main_title">
    <h2 style="color:grey;">¿Porqué usar <span style="color:#48bbc6; font-family: inherit;"><strong>SANUS?</strong></span></h2>
    <p>Diversas razones por las que tener en cuenta nuestra clínica virtual.</p>
    </div>
    	<div class="row">
        	<div class="col-md-6 col-sm-6">
            	<div class="box_feat_home">
                	<i class=" iconcustom-certificate"></i>
                	<h3>Stress Urbano</h3>
                    <p>Lorem ipsum dolor sit amet, vix erat audiam ei. Cum doctus civibus efficiantur in. Nec id tempor imperdiet deterruisset, doctus volumus explicari qui ex, appareat similique an usu.</p>
                </div>
            </div>
            <div class="col-md-6 col-sm-6">
            	<div class="box_feat_home">
                	<i class=" iconcustom-innovation"></i>
                	<h3>Factor Tiempo</h3>
                    <p>Lorem ipsum dolor sit amet, vix erat audiam ei. Cum doctus civibus efficiantur in. Nec id tempor imperdiet deterruisset, doctus volumus explicari qui ex, appareat similique an usu.</p>
                </div>
            </div>
        </div><!-- End row -->
        <div class="row">
        	<div class="col-md-6 col-sm-6">
            	<div class="box_feat_home">
                	<i class=" iconcustom-education_online"></i>
                	<h3>Factor Dsitancia</h3>
                    <p>Lorem ipsum dolor sit amet, vix erat audiam ei. Cum doctus civibus efficiantur in. Nec id tempor imperdiet deterruisset, doctus volumus explicari qui ex, appareat similique an usu.</p>
                </div>
            </div>
            <div class="col-md-6 col-sm-6">
            	<div class="box_feat_home">
                	<i class=" iconcustom-know_how"></i>
                	<h3>Especialistas Disponibles</h3>
                    <p>Lorem ipsum dolor sit amet, vix erat audiam ei. Cum doctus civibus efficiantur in. Nec id tempor imperdiet deterruisset, doctus volumus explicari qui ex, appareat similique an usu.</p>
                </div>
            </div>
        </div><!-- End row -->
       
<br><br><br>

<!-- BUTTON -->
    <div class="text-center"><a href="tour.html" class=" button_outline large">Regístrate</a></div>
<!-- BUTTON  -->   
</div>