
     <div id="como" style="background-color: #48bcc7;">
     	<div class="container margin_60" > 
        	<div class="main_title">
                
                 <h2 style="color:white;">¿Cómo usar <span style="color:white; font-family: inherit; padding-top: 20px"><strong>SANUS?</strong></span></h2>


                 <p style="text-align: center; font-size: 20px; margin-top: 30px; margin-bottom: 100px; color: white;">
                         <span style="color:white; font-family: inherit;"><strong>SANUS</strong></span> es una clinica virtual accede a nuestros servicios con estos sencillos pasos desde cualquier pc conectada a internet.
                    </p>
            </div>
            
         <div class="row">
        	<div class="col-md-3 col-sm-3">
            	<a class="box_feat" href="about.html#">
                <i class="pe-7s-diamond"></i>
            	<h3>Registrate</h3>
                <p>Id mea congue dictas, nec et summo mazim impedit. Vim te audiam impetus interpretaris.</p>
            </a>
            </div>
            <div class="col-md-3 col-sm-3">
            	<a class="box_feat" href="about.html#">
                <i class="pe-7s-display2"></i>
            	<h3>Reserva</h3>
                <p>Id mea congue dictas, nec et summo mazim impedit. Vim te audiam impetus interpretaris</p>
            </a>
            </div>
            <div class="col-md-3 col-sm-3">
            	<a class="box_feat" href="about.html#">
                <i class="pe-7s-science"></i>
            	<h3>Paga</h3>
                <p>Id mea congue dictas, nec et summo mazim impedit. Vim te audiam impetus interpretaris</p>
            </a>
            </div>
            <div class="col-md-3 col-sm-3">
            	<a class="box_feat" href="about.html#">
                <i class="pe-7s-rocket"></i>
            	<h3>Consulta</h3>
                <p>Id mea congue dictas, nec et summo mazim impedit. Vim te audiam impetus interpretaris</p>
            </a>
            </div>
            </div><!--End row-->

    	</div>        
     </div>