<!-- Pulse Preloader -->
<div id="preloader">
	<div class="pulse"></div>
</div>
<!-- Pulse Preloader -->